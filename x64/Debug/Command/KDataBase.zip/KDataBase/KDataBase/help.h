#ifndef HELP_H_INCLUDED
#define HELP_H_INCLUDED
#include<cstdio>
#include<iostream>
using namespace std;
class Help{
public:
    void dropHelp();
    void createHelp();
    void selectHelp();
    void insertHelp();
    void updateHelp();
};


#endif // HELP_H_INCLUDED
